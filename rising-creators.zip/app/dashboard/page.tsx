import DashboardRedirect from "./DashboardRedirect";

export default function DashboardPage() {
  return <DashboardRedirect />;
}
